# This is the formal code for the monthly total energy consumption dataset
library(readr)
library(tidyverse)
library(forecast)
library(stats)
library(tseries)
library(ggplot2)

raw_data <- readxl::read_xlsx("/Users/zhy/Desktop/Project 3/Energy Dataset/Data/UK_total_energy_consumption_monthly.xlsx")

train <- ts(raw_data[which(raw_data$Date >= "2010-03-01" & raw_data$Date <= "2022-02-01"), ]$Consumption, start = c(2010,3), frequency = 12)
test <- ts(raw_data[which(raw_data$Date >= "2022-03-01" & raw_data$Date <= "2023-09-01"), ]$Consumption, start = c(2022,3), frequency = 12)
data <- ts(raw_data[which(raw_data$Date >= "2010-03-01" & raw_data$Date <= "2023-09-01"), ]$Consumption, start = c(2010,3), frequency = 12)

bagged_model <- function(train, test, bootstrapped_samples) {
  forecast_length <- length(test)
  forecasts_list <- lapply(bootstrapped_samples, function(sample) {
    fitted_model <- auto.arima(sample, seasonal = TRUE, stepwise = FALSE, parallel = TRUE)
    forecast(fitted_model, h = forecast_length)
  })
  
  all_forecasts <- sapply(forecasts_list, '[[', "mean")
  mean_forecast <- rowMeans(all_forecasts)
  median_forecast <- apply(all_forecasts, 1, median)
  
  mean_accuracy <- accuracy(mean_forecast, test)
  median_accuracy <- accuracy(median_forecast, test)
  
  return(list(
    mean_forecast = mean_forecast,
    median_forecast = median_forecast,
    mean_accuracy = mean_accuracy,
    median_accuracy = median_accuracy
  ))
}

# 2.1 MBB
set.seed(2024)
l <- 24
B <- 100

MBB <- function(data,B,l){
  lambda <- BoxCox.lambda(data, lower = 0, upper = 1)
  data_BC <- BoxCox(data, lambda)
  
  data_stl <- stl(data_BC, s.window = "periodic")
  data_seasonal <- data_stl$time.series[, "seasonal"]
  data_trend <- data_stl$time.series[, "trend"]
  data_remainder <- data_stl$time.series[, "remainder"]
  # Sample floor(n/l)+2 blocks of length l with replacement from data_remainder
  n <- length(data)
  num_blocks <- floor(n / l) + 2
  bootstrap_samples <- list()
  for (i in 1:B) {
    # Create a bootstrap sample
    bootstrap_sample <- c()
    
    # Sample blocks
    while (length(bootstrap_sample) < num_blocks * l) {
      block_start <- sample(1:(n - l + 1), 1)
      block_end <- block_start + l - 1
      bootstrap_sample <- c(bootstrap_sample, data_remainder[block_start:block_end])
    }
    
    # Randomly discard from the beginning
    discard_start <- sample(1:(l - 1), 1)
    bootstrap_sample <- bootstrap_sample[-seq(1, discard_start)]
    
    # Adjust length to match original series
    bootstrap_sample <- bootstrap_sample[1:n]
    
    # Add the sample to the list
    bootstrap_samples[[i]] <- bootstrap_sample + data_seasonal + data_trend
  }
  mbb_result <- lapply(bootstrap_samples, function(x) InvBoxCox(x, lambda))
  return(mbb_result)
}
mbb_series <- MBB(train, B, l)
mbb_model <- bagged_model(train, test, mbb_series)

# 2.2 ARIMA model
arima_model <- forecast(auto.arima(train, seasonal = TRUE, stepwise = FALSE, parallel = TRUE), length(test))

# 2.3 Sieve bootstrap

RSB <- function(data, B){
  lambda <- BoxCox.lambda(data, lower = 0, upper = 1)
  data_BC <- BoxCox(data, lambda)
  
  data_stl <- stl(data_BC, s.window = "periodic")
  data_seasonal <- data_stl$time.series[, "seasonal"]
  data_trend <- data_stl$time.series[, "trend"]
  data_remainder <- data_stl$time.series[, "remainder"]
  
  arma_fit <- auto.arima(data_remainder, seasonal = FALSE, stepwise = FALSE, parallel = TRUE, max.d = 0)
  residuals <- residuals(arma_fit)
  centered_residuals <- residuals - mean(residuals)
  
  rsb_list <- lapply(1:B, function(i) {
    resampled_residuals <- sample(centered_residuals, replace = TRUE)
    InvBoxCox(fitted(arma_fit) + resampled_residuals + data_seasonal + data_trend, lambda)
  })
  return(rsb_list)
}

rsb_series <- RSB(train, B)
rsb_model <- bagged_model(train, test, rsb_series)

accuracy(arima_model, test)
mbb_model$mean_accuracy
mbb_model$median_accuracy
rsb_model$mean_accuracy
rsb_model$median_accuracy

mase_arima <- accuracy(arima_model, test)["Test set", "MAE"] / (sum(abs(diff(train, lag = 12)))/(length(train)-1))
mase_mbb_mean <- mbb_model$mean_accuracy["Test set", "MAE"] / (sum(abs(diff(train, lag = 12)))/(length(train)-1))
mase_rsb_mean <- rsb_model$mean_accuracy["Test set", "MAE"] / (sum(abs(diff(train, lag = 12)))/(length(train)-1))
mase_mbb_median <- mbb_model$median_accuracy["Test set", "MAE"] / (sum(abs(diff(train, lag = 12)))/(length(train)-1))
mase_rsb_median <- rsb_model$median_accuracy["Test set", "MAE"] / (sum(abs(diff(train, lag = 12)))/(length(train)-1))


# autoplot(test) +
#   autolayer(ts(mbb_model$mean_forecast, start = c(2022,3), frequency = 12), series = "MBB Mean") +
#   autolayer(ts(mbb_model$median_forecast, start = c(2022,3), frequency = 12), series = "MBB Median") +
#   autolayer(arima_model$mean, series = "ARIMA") +
#   autolayer(ts(rsb_model$mean_forecast, start = c(2022,3), frequency = 12), series = "RSB Mean") +
#   autolayer(ts(rsb_model$median_forecast, start = c(2022,3), frequency = 12), series = "RSB Median") +
#   theme_minimal() +
#   xlab("Date") +
#   ylab("Million of tonnes of oil equivalent") +
#   ggtitle("UK Total Energy Consumption") +
#   theme(plot.title = element_text(hjust = 0.5))

# autoplot(data, series = "Train Set") +
#   autolayer(test, series = "Test Set") +
#   geom_vline(xintercept = time(test)[1], linetype = "dashed", colour = "red" ) +
#   theme_minimal() +
#   xlab("Date") +
#   ylab("Million Cubic Metres") +
#   ggtitle("UK Gas Consumption (Monthly)") +
#   theme(plot.title = element_text(hjust = 0.5)) +
#   annotate("text", x = time(train)[length(train)/2], y = min(data), label = "Train Set", size = 5, hjust = 0.5) +
#   annotate("text", x = time(test)[length(test)/2], y = min(data), label = "Test Set", size = 5, hjust = 0.5)

# Perform the cross-validation for mbb_series and rsb_series and arima_model
# arima_cv <- tsCV(train, arima_model, drift = TRUE, h=1)
# rmse_arima_cv <- sqrt(mean(residuals(rwf(goog200, drift=TRUE))^2, na.rm=TRUE))



